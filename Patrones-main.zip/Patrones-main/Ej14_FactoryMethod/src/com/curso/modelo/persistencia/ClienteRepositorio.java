package com.curso.modelo.persistencia;

import com.curso.modelo.entidad.Cliente;

public interface ClienteRepositorio {

	void insertar(Cliente cliente);
	
}