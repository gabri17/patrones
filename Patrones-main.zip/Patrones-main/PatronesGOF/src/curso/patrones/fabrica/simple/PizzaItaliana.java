package curso.patrones.fabrica.simple;

public class PizzaItaliana extends Pizza {

}
