package curso.patrones.fabrica.simple.problema;

public class PizzaAmericana extends Pizza {

}
