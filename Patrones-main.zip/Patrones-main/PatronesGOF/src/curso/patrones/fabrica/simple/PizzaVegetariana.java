package curso.patrones.fabrica.simple;

public class PizzaVegetariana extends Pizza {

}
