package curso.patrones.fabrica.simple.problema;

public class PizzaVegetariana extends Pizza {

}
