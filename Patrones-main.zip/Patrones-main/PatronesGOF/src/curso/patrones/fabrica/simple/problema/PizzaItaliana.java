package curso.patrones.fabrica.simple.problema;

public class PizzaItaliana extends Pizza {

}
