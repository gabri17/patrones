package curso.patrones.fabrica.simple;

public class PizzaAmericana extends Pizza {

}
