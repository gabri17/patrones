package curso.patrones.fabrica.AbstractFactory.problema;

public class Programa {
	public static void main(String[] args) {
		VentanaRoja ventanaRoja=new VentanaRoja();
		VentanaAzul ventanaAzul=new VentanaAzul();
	}
}
