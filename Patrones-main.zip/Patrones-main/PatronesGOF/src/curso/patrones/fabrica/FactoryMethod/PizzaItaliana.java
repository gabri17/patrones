package curso.patrones.fabrica.FactoryMethod;

public class PizzaItaliana extends Pizza {

}
