package curso.patrones.fabrica.FactoryMethod.problema;

public class PizzaAmericanaMadrid extends Pizza {

}
