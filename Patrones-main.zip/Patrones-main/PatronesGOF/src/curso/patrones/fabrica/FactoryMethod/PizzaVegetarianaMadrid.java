package curso.patrones.fabrica.FactoryMethod;

public class PizzaVegetarianaMadrid extends Pizza {

}
