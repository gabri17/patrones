package curso.patrones.fabrica.FactoryMethod;

public class PizzaItalianaCaceres extends Pizza {

}
