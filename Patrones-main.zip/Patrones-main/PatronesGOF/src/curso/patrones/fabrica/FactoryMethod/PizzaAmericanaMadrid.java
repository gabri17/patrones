package curso.patrones.fabrica.FactoryMethod;

public class PizzaAmericanaMadrid extends Pizza {

}
