package curso.patrones.fabrica.FactoryMethod;

public class PizzaAmericana extends Pizza {

}
