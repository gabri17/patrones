package curso.patrones.fabrica.FactoryMethod;

public class PizzaVegetarianaCaceres extends Pizza {

}
