package curso.patrones.fabrica.FactoryMethod;

public class PizzaItalianaMadrid extends Pizza {

}
