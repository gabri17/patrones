package curso.patrones.fabrica.FactoryMethod.problema;

public class PizzaAmericanaCaceres extends Pizza {

}
