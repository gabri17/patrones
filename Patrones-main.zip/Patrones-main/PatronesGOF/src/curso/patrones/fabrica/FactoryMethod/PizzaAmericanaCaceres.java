package curso.patrones.fabrica.FactoryMethod;

public class PizzaAmericanaCaceres extends Pizza {

}
