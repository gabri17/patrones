package curso.patrones.fabrica.FactoryMethod.problema;

public class PizzaVegetariana extends Pizza {

}
