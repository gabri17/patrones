package curso.patrones.fabrica.FactoryMethod.problema;

public class PizzaVegetarianaMadrid extends Pizza {

}
