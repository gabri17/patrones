package curso.patrones.fabrica.FactoryMethod.problema;

public class PizzaItalianaCaceres extends Pizza {

}
