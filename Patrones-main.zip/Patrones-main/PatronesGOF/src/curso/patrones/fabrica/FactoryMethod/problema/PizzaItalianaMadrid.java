package curso.patrones.fabrica.FactoryMethod.problema;

public class PizzaItalianaMadrid extends Pizza {

}
