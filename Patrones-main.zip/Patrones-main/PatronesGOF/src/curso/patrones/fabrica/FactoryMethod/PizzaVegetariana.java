package curso.patrones.fabrica.FactoryMethod;

public class PizzaVegetariana extends Pizza {

}
