package curso.patrones.fabrica.FactoryMethod.problema;

public class PizzaAmericana extends Pizza {

}
