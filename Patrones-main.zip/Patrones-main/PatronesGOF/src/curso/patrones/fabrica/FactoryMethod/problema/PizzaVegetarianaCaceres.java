package curso.patrones.fabrica.FactoryMethod.problema;

public class PizzaVegetarianaCaceres extends Pizza {

}
