package curso.patrones.fabrica.FactoryMethod.problema;

public class PizzaItaliana extends Pizza {

}
