package curso.patrones.cadenaresponsabilidad.problema;

public class Facturacion {
	public void facturar(Factura factura){
		System.out.println("facturando "+factura);
	}
}
