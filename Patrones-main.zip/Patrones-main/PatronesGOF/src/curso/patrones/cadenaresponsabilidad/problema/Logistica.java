package curso.patrones.cadenaresponsabilidad.problema;

public class Logistica {
	public void preparar(Factura factura){
		System.out.println("preparando "+factura);
	}
}
