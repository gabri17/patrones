package curso.patrones.cadenaresponsabilidad.problema;

public class Comercial {
	public void procesar(Factura factura){
		System.out.println("procesando "+factura);
	}
}
