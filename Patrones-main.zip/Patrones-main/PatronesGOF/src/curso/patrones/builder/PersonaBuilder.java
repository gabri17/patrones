package curso.patrones.builder;

public interface PersonaBuilder {

	public Persona construir();

}