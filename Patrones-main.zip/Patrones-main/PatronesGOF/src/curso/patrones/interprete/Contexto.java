package curso.patrones.interprete;

public class Contexto {
	protected String entrada;
	protected int salida;
	
	public Contexto(String s){
		entrada = s;
	}
}
