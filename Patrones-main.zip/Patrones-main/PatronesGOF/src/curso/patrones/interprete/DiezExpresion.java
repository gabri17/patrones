package curso.patrones.interprete;

public class DiezExpresion extends Expresion {

	@Override
	public String uno() {
		// TODO Auto-generated method stub
		return "X";
	}

	@Override
	public String cuatro() {
		// TODO Auto-generated method stub
		return "XL";
	}

	@Override
	public String cinco() {
		// TODO Auto-generated method stub
		return "L";
	}

	@Override
	public String nueve() {
		// TODO Auto-generated method stub
		return "XC";
	}

	@Override
	public int multiplicador() {
		// TODO Auto-generated method stub
		return 10;
	}

}
