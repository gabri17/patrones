package curso.patrones.interprete;

public class CienExpresion extends Expresion {

	@Override
	public String uno() {
		// TODO Auto-generated method stub
		return "C";
	}

	@Override
	public String cuatro() {
		// TODO Auto-generated method stub
		return "CD";
	}

	@Override
	public String cinco() {
		// TODO Auto-generated method stub
		return "D";
	}

	@Override
	public String nueve() {
		// TODO Auto-generated method stub
		return "CM";
	}

	@Override
	public int multiplicador() {
		// TODO Auto-generated method stub
		return 100;
	}

}
