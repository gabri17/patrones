package curso.patrones.interprete;

public class MilExpresion extends Expresion {

	@Override
	public String uno() {
		// TODO Auto-generated method stub
		return "M";
	}

	@Override
	public String cuatro() {
		// TODO Auto-generated method stub
		return " ";
	}

	@Override
	public String cinco() {
		// TODO Auto-generated method stub
		return "M";
	}

	@Override
	public String nueve() {
		// TODO Auto-generated method stub
		return " ";
	}

	@Override
	public int multiplicador() {
		// TODO Auto-generated method stub
		return 1000;
	}

}
