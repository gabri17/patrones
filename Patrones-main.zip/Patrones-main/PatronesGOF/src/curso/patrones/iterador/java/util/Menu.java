package curso.patrones.iterador.java.util;

import java.util.Iterator;

public interface Menu {

	public abstract Iterator crearIterador();

}