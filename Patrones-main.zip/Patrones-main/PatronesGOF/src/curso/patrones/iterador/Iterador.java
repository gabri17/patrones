package curso.patrones.iterador;

public interface Iterador {
	public boolean tieneSiguiente();
	public Object siguiente();
}
