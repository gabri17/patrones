package curso.patrones.fachada.problema;

public class TV extends Aparato {

}
