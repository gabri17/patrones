package curso.patrones.fachada.problema;

public class EquipoHIFI extends Aparato {

}
