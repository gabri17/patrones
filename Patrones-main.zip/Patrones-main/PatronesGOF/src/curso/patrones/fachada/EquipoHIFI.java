package curso.patrones.fachada;

public class EquipoHIFI extends Aparato {

}
