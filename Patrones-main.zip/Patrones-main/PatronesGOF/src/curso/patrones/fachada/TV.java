package curso.patrones.fachada;

public class TV extends Aparato {

}
