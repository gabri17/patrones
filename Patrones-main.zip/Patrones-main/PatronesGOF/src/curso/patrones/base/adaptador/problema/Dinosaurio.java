package curso.patrones.base.adaptador.problema;

public abstract class Dinosaurio {
	public abstract void rugir();
	public abstract void pasarPorElAgua();
	public abstract void volar();
}
