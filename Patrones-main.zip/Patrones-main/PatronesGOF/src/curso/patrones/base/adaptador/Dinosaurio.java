package curso.patrones.base.adaptador;

public abstract class Dinosaurio {
	public abstract void rugir();
	public abstract void pasarPorElAgua();
	public abstract void volar();
}
