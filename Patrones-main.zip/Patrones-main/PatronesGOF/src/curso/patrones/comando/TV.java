package curso.patrones.comando;

public class TV {

	public void on(){
		System.out.println("tv encendida.");
	}
	
	public void off(){
		System.out.println("tv apagada.");
	}
	
}
