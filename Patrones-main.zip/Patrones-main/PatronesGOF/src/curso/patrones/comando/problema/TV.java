package curso.patrones.comando.problema;

public class TV {

	public void on(){
		System.out.println("tv encendida.");
	}
	
	public void off(){
		System.out.println("tv apagada.");
	}
	
}
