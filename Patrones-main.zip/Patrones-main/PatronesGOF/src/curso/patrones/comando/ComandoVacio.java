package curso.patrones.comando;

public class ComandoVacio implements Comando {

	public void ejecutar() {
		System.out.println("vacio.");

	}

	public void deshacer() {
				
	}

}
