package curso.patrones.comando;

public interface Comando {
	public void ejecutar();
	public void deshacer();
}
