package curso.patrones.comando;

public class CadenaHIFI {
	int volumen;

	public int getVolumen() {
		return volumen;
	}

	public void setVolumen(int volumen) {
		this.volumen = volumen;
		System.out.println("cadena volumen="+volumen);
	}
	
	
}
