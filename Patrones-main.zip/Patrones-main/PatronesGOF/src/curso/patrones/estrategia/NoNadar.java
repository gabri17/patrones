package curso.patrones.estrategia;

public class NoNadar extends ComportamientoNadador {

	@Override
	public void nadar() {
		System.out.println("me ahogo!!");

	}

}
