package curso.patrones.estrategia;

public class PonerHuevos extends ComportamientoReproductor {

	@Override
	public void reproducirse() {
		System.out.println("he puesto un huevo");

	}

}
