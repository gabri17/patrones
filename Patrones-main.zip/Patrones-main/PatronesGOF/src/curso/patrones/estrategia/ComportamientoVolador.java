package curso.patrones.estrategia;

public abstract class ComportamientoVolador {
	public abstract void volar();
}
