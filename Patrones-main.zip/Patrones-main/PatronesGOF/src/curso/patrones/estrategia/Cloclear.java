package curso.patrones.estrategia;

public class Cloclear extends ComportamientoCantador {

	@Override
	public void cantar() {
		System.out.println("clo,clo,clo");

	}

}
