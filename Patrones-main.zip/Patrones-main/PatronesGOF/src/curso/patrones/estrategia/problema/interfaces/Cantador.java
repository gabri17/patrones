package curso.patrones.estrategia.problema.interfaces;

public interface Cantador {
	public void cantar(); 
}
