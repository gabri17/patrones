package curso.patrones.estrategia.problema.interfaces;

public class Avestruz extends Ave {

	@Override
	public void mostrar() {
		System.out.println("soy avestruz");

	}
	

}
