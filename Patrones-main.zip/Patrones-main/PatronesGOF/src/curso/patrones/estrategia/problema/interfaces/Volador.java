package curso.patrones.estrategia.problema.interfaces;

public interface Volador {
	public void volar();
}
