package curso.patrones.estrategia.problema.interfaces;

public abstract  class Ave {

	
	public abstract void mostrar();
	

	
}
