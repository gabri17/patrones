package curso.patrones.estrategia.problema.interfaces;

public interface Nadador {
	public void nadar();
}
