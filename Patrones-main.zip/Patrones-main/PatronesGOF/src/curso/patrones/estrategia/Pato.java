package curso.patrones.estrategia;

public class Pato extends Ave {

	@Override
	public void mostrar() {
		System.out.println("soy un pato");

	}


}
