package curso.patrones.estrategia;

public abstract class ComportamientoCantador {
	public abstract void cantar(); 
}
