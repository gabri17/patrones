package curso.patrones.estrategia;

public class VolarConAlas extends ComportamientoVolador {

	@Override
	public void volar() {
		System.out.println("volando voy con mis alas");

	}

}
