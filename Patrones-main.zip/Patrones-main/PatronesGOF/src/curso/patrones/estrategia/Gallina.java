package curso.patrones.estrategia;

public class Gallina extends Ave {

	@Override
	public void mostrar() {
		System.out.println("soy una gallina");

	}


	


}
