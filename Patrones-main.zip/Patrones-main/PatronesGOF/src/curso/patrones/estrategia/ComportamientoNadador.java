package curso.patrones.estrategia;

public abstract  class ComportamientoNadador {
	public abstract void nadar();
}
