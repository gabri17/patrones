package curso.patrones.estrategia;

public class NadarEnRio extends ComportamientoNadador {

	@Override
	public void nadar() {
		System.out.println("nadando en el rio");

	}

}
