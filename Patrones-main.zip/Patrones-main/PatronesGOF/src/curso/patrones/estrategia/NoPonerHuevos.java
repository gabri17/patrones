package curso.patrones.estrategia;

public class NoPonerHuevos extends ComportamientoReproductor{

	@Override
	public void reproducirse() {
		System.out.println("yo no pongo huevos");
		
	}

}
