package curso.patrones.estrategia;

public abstract class ComportamientoReproductor {
	public abstract void reproducirse();
}
