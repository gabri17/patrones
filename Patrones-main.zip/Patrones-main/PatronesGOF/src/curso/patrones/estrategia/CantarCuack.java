package curso.patrones.estrategia;

public class CantarCuack extends ComportamientoCantador {

	@Override
	public void cantar() {
		System.out.println("cuack, cuack");

	}

}
