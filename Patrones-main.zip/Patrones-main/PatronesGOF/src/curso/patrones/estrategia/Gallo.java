package curso.patrones.estrategia;

public class Gallo extends Ave {

	@Override
	public void mostrar() {
		System.out.println("soy un gallo");

	}

}
