package curso.patrones.estrategia;

public class Avestruz extends Ave {

	@Override
	public void mostrar() {
		System.out.println("soy avestruz");

	}
	

}
